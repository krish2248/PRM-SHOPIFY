/**
 * PRM HerboVilla Theme JavaScript
 * Premium Ayurvedic Wellness Brand
 */

(function() {
  'use strict';

  // ============================================
  // UTILITY FUNCTIONS
  // ============================================
  
  const debounce = (fn, delay) => {
    let timeoutId;
    return (...args) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => fn.apply(this, args), delay);
    };
  };

  const formatMoney = (cents, format = '₹{{amount}}') => {
    if (typeof cents === 'string') cents = cents.replace('.', '');
    const value = (cents / 100).toFixed(2);
    return format.replace('{{amount}}', value).replace('{{amount_no_decimals}}', Math.floor(cents / 100));
  };

  const fetchJSON = async (url, options = {}) => {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        ...options.headers
      }
    });
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return response.json();
  };

  // ============================================
  // HEADER
  // ============================================
  
  class Header {
    constructor() {
      this.header = document.querySelector('.header');
      this.menuToggle = document.querySelector('.header__menu-toggle');
      this.mobileMenu = document.querySelector('.mobile-menu');
      this.mobileMenuClose = document.querySelector('.mobile-menu__close');
      
      this.init();
    }

    init() {
      if (this.header) {
        this.handleScroll();
        window.addEventListener('scroll', debounce(() => this.handleScroll(), 10));
      }

      if (this.menuToggle && this.mobileMenu) {
        this.menuToggle.addEventListener('click', () => this.openMobileMenu());
        this.mobileMenuClose?.addEventListener('click', () => this.closeMobileMenu());
      }
    }

    handleScroll() {
      if (window.scrollY > 50) {
        this.header.classList.add('header--scrolled');
      } else {
        this.header.classList.remove('header--scrolled');
      }
    }

    openMobileMenu() {
      this.mobileMenu.classList.add('mobile-menu--open');
      document.body.classList.add('no-scroll');
      document.querySelector('.overlay')?.classList.add('overlay--visible');
    }

    closeMobileMenu() {
      this.mobileMenu.classList.remove('mobile-menu--open');
      document.body.classList.remove('no-scroll');
      document.querySelector('.overlay')?.classList.remove('overlay--visible');
    }
  }

  // ============================================
  // CART DRAWER
  // ============================================
  
  class CartDrawer {
    constructor() {
      this.drawer = document.querySelector('.cart-drawer');
      this.overlay = document.querySelector('.overlay');
      this.cartCount = document.querySelector('.header__cart-count');
      this.cartTriggers = document.querySelectorAll('[data-cart-toggle]');
      this.closeBtn = document.querySelector('.cart-drawer__close');
      
      this.init();
    }

    init() {
      this.cartTriggers.forEach(trigger => {
        trigger.addEventListener('click', (e) => {
          e.preventDefault();
          this.open();
        });
      });

      this.closeBtn?.addEventListener('click', () => this.close());
      this.overlay?.addEventListener('click', () => this.close());

      document.addEventListener('cart:updated', (e) => this.render(e.detail));
      
      // Listen for add to cart forms
      document.addEventListener('submit', async (e) => {
        const form = e.target.closest('form[action="/cart/add"]');
        if (form) {
          e.preventDefault();
          await this.addItem(form);
        }
      });

      // Quick add buttons
      document.addEventListener('click', async (e) => {
        const btn = e.target.closest('[data-add-to-cart]');
        if (btn) {
          e.preventDefault();
          const variantId = btn.dataset.variantId;
          const quantity = btn.dataset.quantity || 1;
          await this.addItemById(variantId, quantity, btn);
        }
      });
    }

    open() {
      this.drawer?.classList.add('cart-drawer--open');
      this.overlay?.classList.add('overlay--visible');
      document.body.classList.add('no-scroll');
      this.fetchCart();
    }

    close() {
      this.drawer?.classList.remove('cart-drawer--open');
      this.overlay?.classList.remove('overlay--visible');
      document.body.classList.remove('no-scroll');
    }

    async fetchCart() {
      try {
        const cart = await fetchJSON('/cart.js');
        this.render(cart);
      } catch (error) {
        console.error('Error fetching cart:', error);
      }
    }

    async addItem(form) {
      const submitBtn = form.querySelector('[type="submit"]');
      submitBtn?.classList.add('btn--loading');
      
      try {
        const formData = new FormData(form);
        const response = await fetch('/cart/add.js', {
          method: 'POST',
          body: formData
        });
        
        if (!response.ok) throw new Error('Add to cart failed');
        
        await this.fetchCart();
        this.open();
      } catch (error) {
        console.error('Error adding to cart:', error);
      } finally {
        submitBtn?.classList.remove('btn--loading');
      }
    }

    async addItemById(variantId, quantity, btn) {
      btn?.classList.add('btn--loading');
      
      try {
        await fetchJSON('/cart/add.js', {
          method: 'POST',
          body: JSON.stringify({
            items: [{ id: variantId, quantity: parseInt(quantity) }]
          })
        });
        
        await this.fetchCart();
        this.open();
      } catch (error) {
        console.error('Error adding to cart:', error);
      } finally {
        btn?.classList.remove('btn--loading');
      }
    }

    async updateItem(key, quantity) {
      try {
        const cart = await fetchJSON('/cart/change.js', {
          method: 'POST',
          body: JSON.stringify({ id: key, quantity })
        });
        this.render(cart);
        this.updateCartCount(cart.item_count);
      } catch (error) {
        console.error('Error updating cart:', error);
      }
    }

    async removeItem(key) {
      await this.updateItem(key, 0);
    }

    render(cart) {
      const itemsContainer = this.drawer?.querySelector('.cart-drawer__items');
      const subtotalEl = this.drawer?.querySelector('.cart-drawer__subtotal-amount');
      const checkoutBtn = this.drawer?.querySelector('.cart-drawer__checkout');
      
      this.updateCartCount(cart.item_count);

      if (!itemsContainer) return;

      if (cart.item_count === 0) {
        itemsContainer.innerHTML = `
          <div class="cart-drawer__empty">
            <p>Your cart is empty</p>
            <a href="/collections/all" class="btn btn--primary mt-lg">Continue Shopping</a>
          </div>
        `;
        if (checkoutBtn) checkoutBtn.style.display = 'none';
        return;
      }

      if (checkoutBtn) checkoutBtn.style.display = 'block';

      itemsContainer.innerHTML = cart.items.map(item => `
        <div class="cart-drawer__item" data-key="${item.key}">
          <div class="cart-drawer__item-image">
            <img src="${item.image || item.featured_image.url}" alt="${item.title}" loading="lazy">
          </div>
          <div class="cart-drawer__item-details">
            <h4 class="cart-drawer__item-title">${item.product_title}</h4>
            ${item.variant_title ? `<p class="cart-drawer__item-variant">${item.variant_title}</p>` : ''}
            <p class="cart-drawer__item-price">${formatMoney(item.final_line_price)}</p>
            <div class="cart-drawer__item-actions">
              <div class="quantity-selector quantity-selector--sm">
                <button type="button" class="quantity-selector__btn" data-action="decrease" data-key="${item.key}">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                </button>
                <input type="number" class="quantity-selector__input" value="${item.quantity}" min="1" data-key="${item.key}">
                <button type="button" class="quantity-selector__btn" data-action="increase" data-key="${item.key}">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                </button>
              </div>
              <button type="button" class="cart-drawer__item-remove" data-action="remove" data-key="${item.key}">Remove</button>
            </div>
          </div>
        </div>
      `).join('');

      if (subtotalEl) {
        subtotalEl.textContent = formatMoney(cart.total_price);
      }

      // Add event listeners for quantity buttons
      itemsContainer.querySelectorAll('[data-action]').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const key = btn.dataset.key;
          const action = btn.dataset.action;
          const input = itemsContainer.querySelector(`input[data-key="${key}"]`);
          let quantity = parseInt(input?.value || 1);

          if (action === 'increase') quantity++;
          else if (action === 'decrease') quantity = Math.max(0, quantity - 1);
          else if (action === 'remove') quantity = 0;

          this.updateItem(key, quantity);
        });
      });
    }

    updateCartCount(count) {
      if (this.cartCount) {
        this.cartCount.textContent = count;
        this.cartCount.style.display = count > 0 ? 'flex' : 'none';
      }
    }
  }

  // ============================================
  // PRODUCT GALLERY
  // ============================================
  
  class ProductGallery {
    constructor(container) {
      this.container = container;
      this.mainImage = container.querySelector('.product-gallery__main img');
      this.thumbs = container.querySelectorAll('.product-gallery__thumb');
      
      this.init();
    }

    init() {
      this.thumbs.forEach(thumb => {
        thumb.addEventListener('click', () => this.selectThumb(thumb));
      });
    }

    selectThumb(thumb) {
      this.thumbs.forEach(t => t.classList.remove('product-gallery__thumb--active'));
      thumb.classList.add('product-gallery__thumb--active');
      
      const img = thumb.querySelector('img');
      if (img && this.mainImage) {
        this.mainImage.src = img.src.replace('_100x', '_800x');
        this.mainImage.srcset = '';
      }
    }
  }

  // ============================================
  // PRODUCT VARIANTS
  // ============================================
  
  class ProductVariants {
    constructor(container) {
      this.container = container;
      this.form = container.querySelector('form[action="/cart/add"]');
      this.variantInput = this.form?.querySelector('[name="id"]');
      this.priceEl = container.querySelector('.product-info__price-current');
      this.comparePriceEl = container.querySelector('.product-info__price-compare');
      this.options = container.querySelectorAll('.product-variant__option');
      this.productJson = this.getProductJson();
      
      this.init();
    }

    getProductJson() {
      const script = this.container.querySelector('[type="application/json"][data-product-json]');
      return script ? JSON.parse(script.textContent) : null;
    }

    init() {
      this.options.forEach(option => {
        option.addEventListener('click', () => this.selectOption(option));
      });
    }

    selectOption(option) {
      const group = option.closest('.product-variant__options');
      group?.querySelectorAll('.product-variant__option').forEach(o => {
        o.classList.remove('product-variant__option--selected');
      });
      option.classList.add('product-variant__option--selected');
      
      this.updateVariant();
    }

    updateVariant() {
      if (!this.productJson) return;

      const selectedOptions = Array.from(this.container.querySelectorAll('.product-variant__option--selected'))
        .map(o => o.textContent.trim());

      const variant = this.productJson.variants.find(v => {
        return v.options.every((opt, i) => opt === selectedOptions[i]);
      });

      if (variant) {
        if (this.variantInput) this.variantInput.value = variant.id;
        if (this.priceEl) this.priceEl.textContent = formatMoney(variant.price);
        if (this.comparePriceEl) {
          if (variant.compare_at_price > variant.price) {
            this.comparePriceEl.textContent = formatMoney(variant.compare_at_price);
            this.comparePriceEl.style.display = 'inline';
          } else {
            this.comparePriceEl.style.display = 'none';
          }
        }
      }
    }
  }

  // ============================================
  // QUANTITY SELECTOR
  // ============================================
  
  class QuantitySelector {
    constructor(container) {
      this.container = container;
      this.input = container.querySelector('.quantity-selector__input');
      this.decreaseBtn = container.querySelector('[data-action="decrease"]');
      this.increaseBtn = container.querySelector('[data-action="increase"]');
      
      this.init();
    }

    init() {
      this.decreaseBtn?.addEventListener('click', () => this.decrease());
      this.increaseBtn?.addEventListener('click', () => this.increase());
      this.input?.addEventListener('change', () => this.validate());
    }

    decrease() {
      const current = parseInt(this.input.value) || 1;
      this.input.value = Math.max(1, current - 1);
      this.input.dispatchEvent(new Event('change', { bubbles: true }));
    }

    increase() {
      const current = parseInt(this.input.value) || 1;
      this.input.value = current + 1;
      this.input.dispatchEvent(new Event('change', { bubbles: true }));
    }

    validate() {
      const value = parseInt(this.input.value);
      if (isNaN(value) || value < 1) {
        this.input.value = 1;
      }
    }
  }

  // ============================================
  // ACCORDIONS
  // ============================================
  
  class Accordion {
    constructor(container) {
      this.container = container;
      this.trigger = container.querySelector('.product-accordion__trigger');
      
      this.init();
    }

    init() {
      this.trigger?.addEventListener('click', () => this.toggle());
    }

    toggle() {
      this.container.classList.toggle('product-accordion--open');
    }
  }

  // ============================================
  // CAROUSEL
  // ============================================
  
  class Carousel {
    constructor(container) {
      this.container = container;
      this.track = container.querySelector('[data-carousel-track]');
      this.prevBtn = container.querySelector('[data-carousel-prev]');
      this.nextBtn = container.querySelector('[data-carousel-next]');
      
      if (this.track) this.init();
    }

    init() {
      this.prevBtn?.addEventListener('click', () => this.scroll(-1));
      this.nextBtn?.addEventListener('click', () => this.scroll(1));
    }

    scroll(direction) {
      const item = this.track.querySelector(':scope > *');
      if (!item) return;
      
      const itemWidth = item.offsetWidth + parseInt(getComputedStyle(this.track).gap || 0);
      this.track.scrollBy({ left: direction * itemWidth, behavior: 'smooth' });
    }
  }

  // ============================================
  // NEWSLETTER FORM
  // ============================================
  
  class NewsletterForm {
    constructor(form) {
      this.form = form;
      this.init();
    }

    init() {
      this.form.addEventListener('submit', async (e) => {
        // Let Shopify handle the form submission
        // This is just for visual feedback
        const btn = this.form.querySelector('[type="submit"]');
        btn?.classList.add('btn--loading');
      });
    }
  }

  // ============================================
  // SMOOTH SCROLL
  // ============================================
  
  const initSmoothScroll = () => {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', (e) => {
        const targetId = anchor.getAttribute('href');
        if (targetId === '#') return;
        
        const target = document.querySelector(targetId);
        if (target) {
          e.preventDefault();
          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    });
  };

  // ============================================
  // ANIMATION ON SCROLL
  // ============================================
  
  const initScrollAnimations = () => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-slide-up');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('[data-animate]').forEach(el => {
      observer.observe(el);
    });
  };

  // ============================================
  // INITIALIZE
  // ============================================
  
  const init = () => {
    // Header
    new Header();

    // Cart Drawer
    new CartDrawer();

    // Product Gallery
    document.querySelectorAll('.product-gallery').forEach(el => {
      new ProductGallery(el);
    });

    // Product Variants
    document.querySelectorAll('.product-page').forEach(el => {
      new ProductVariants(el);
    });

    // Quantity Selectors
    document.querySelectorAll('.quantity-selector').forEach(el => {
      new QuantitySelector(el);
    });

    // Accordions
    document.querySelectorAll('.product-accordion').forEach(el => {
      new Accordion(el);
    });

    // Carousels
    document.querySelectorAll('[data-carousel]').forEach(el => {
      new Carousel(el);
    });

    // Newsletter Forms
    document.querySelectorAll('.newsletter__form').forEach(el => {
      new NewsletterForm(el);
    });

    // Smooth Scroll
    initSmoothScroll();

    // Scroll Animations
    initScrollAnimations();

    // Overlay click to close everything
    document.querySelector('.overlay')?.addEventListener('click', () => {
      document.querySelector('.mobile-menu')?.classList.remove('mobile-menu--open');
      document.querySelector('.cart-drawer')?.classList.remove('cart-drawer--open');
      document.querySelector('.overlay')?.classList.remove('overlay--visible');
      document.body.classList.remove('no-scroll');
    });
  };

  // Run on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
